<?php 
$connect = mysqli_connect('localhost', 'root', 'root', 'qwe');
// if($connect) {
//    print_r("Подключение успешно");
// } else {
//    print_r("Произошла ошибка");
// }
