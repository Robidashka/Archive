<?
require_once("../connect.php");

$id = $_POST["id"];
$title = $_POST["title"];
$content = $_POST["content"];
$img = $_POST["img"];
$author = $_POST["author"];

if(!empty($id)){
    $sql = "UPDATE users SET title = '$title', content ='$content', img ='$img' , author ='$author' WHERE id='$id'";
}

if ($connect->query($sql)) {
    header("Location:../index.php");
    }
    else {
        print_r("Error");
    }