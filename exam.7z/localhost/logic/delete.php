<?
require_once("../connect.php");

$del = $_POST["id"];

if(!empty($id)){
    $del1 = "DELETE FROM users WHERE id = '$id'";
}

if ($connect->query($del1)) {
    header("Location:../index.php");
    }
    else {
        print_r("Error");
    }