<?
require_once("../connect.php");

$title = $_POST["title"];
$content = $_POST["content"];
$img = $_POST["img"];
$author = $_POST["author"];

mysqli_query($connect, "INSERT INTO `users` (`title`, `content`, `img`, `author`) VALUES ( '$title', '$content' , '$img' , '$author')");

header("Location:../index.php");