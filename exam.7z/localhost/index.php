<?php 
    require_once("connect.php");
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Авторизация и регистрация</title>
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
		<div class="create">
			<h1>Добавить пост</h1>
    	    <form action="logic/create.php" method="POST">
    	        <input type="text" name="title" placeholder="title">
    	        <input type="text" name="content" placeholder="content">
    	        <select name="img">
					<option value="1.jpg">aqua</option>
					<option value="2.jpg">aaaa</option>
					<option value="3.jpg">bbbb</option>
				</select>
    	        <input type="text" name="author" placeholder="author">
    	        <button type="submit">Добавить</button>
    	    </form>
    	</div>
		<h2>Посты</h2>
        <?php if($result = mysqli_query($connect, "SELECT * FROM `users`")): foreach($result as $row):?> 
			<div class="1">
				<div class="2">
					<span class="3"><?php echo $row["datetime"];?> by <?php echo $row["author"];?></span>
					<h2 class="4"><?php echo $row["title"];?></h2>
				</div>
				<div class="5">
					<img src="img/<?php echo $row["img"];?>">
				</div>
				<div class="6">
					<p><?php echo $row["content"];?></p>
				</div>
                <div class="7">
					<form action="logic/update.php" method="POST">
						<input type="hidden" name="id" value="<?= $row['id'] ?>">
    	        		<input type="text" name="title" placeholder="title">
    	        		<input type="text" name="content" placeholder="content">
						<select name="img">
							<option value="1.jpg">aqua</option>
							<option value="2.jpg">aaaa</option>
							<option value="3.jpg">bbbb</option>
						</select>
    	        		<input type="text" name="author" placeholder="author">
    	        		<button type="submit">Добавить</button>
    	    		</form>
					</form>
                    <form action="logic/delete.php" method="POST">
                        <input type="hidden" name="del" value="<?= $row['id'] ?>">
                        <button type="submit">Удалить</button>
                    </form>
				</div>
			</div>
		<?php endforeach;endif;?>
    </body>
</html>